import numpy as np
import pandas as pd
import tushare as ts
from scipy.stats import norm
#df = pd.read_excel('上证指数历史数据1.xlsx')
df = pd.read_excel(r'xin3.xlsx')
#各列数据分别为收盘	开盘	高	低	交易量	涨跌幅
#print(df.head())
u = df.涨1.mean()
σ2 = df.涨1.var()
σ = df.涨1.std()

# 置信度为 99% 时的 VaR
Z_01 = -norm.ppf(0.99)
print(Z_01*σ - u)


# 置信度为 95% 时的 VaR
Z_05 = -norm.ppf(0.95)
print(Z_05*σ - u)


# 置信度为 90% 时的 VaR
Z_10 = -norm.ppf(0.90)
print(Z_10*σ - u)