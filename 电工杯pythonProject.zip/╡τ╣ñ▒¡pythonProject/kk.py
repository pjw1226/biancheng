import mpl_finance as mpf
from matplotlib import pyplot as plt
import numpy as np
import pandas as pd

fig = plt.figure(figsize=(12, 8))
ax = fig.add_subplot(111)
# 加载数据
df_ma = pd.DataFrame()
original_data = pd.read_excel('gf.xlsx')
#print(original_data)
# 设置显示的交易日数
days = 524
# 生成开盘价、收盘价、最高价、最低价
opens = original_data['开盘'][0:days]
closes = original_data['收盘'][0:days]
highs = original_data['最高'][0:days]
lows = original_data['最低'][0:days]
# 生成时间序列
#data_index = original_data['日期'][0:days]
# 使用zip()生成数据列表
ohlc = list(zip(np.arange(0, len(opens)), opens, closes, highs, lows))
# 绘制k线图
mpf.candlestick2_ochl(ax, opens, closes, highs, lows, width=0.6, colorup='r', colordown='g')
# 设置x轴的范围
ax.set_xlim(0, days)
# x轴刻度设置
ax.set_xticks(np.arange(0, days, 100))
# 标签设置为日期
#ax.set_xticklabels([data_index[index] for index in ax.get_xticks()])
# 设置轴标签
ax.set_xlabel('time', fontsize=15)
ax.set_ylabel('price', fontsize=15)
ax.set_title('K-line diagram of integrated photovoltaic sector')

plt.show()